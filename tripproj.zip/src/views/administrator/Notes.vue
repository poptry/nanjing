<template>
  <div class="manage">
    <el-dialog title="留言信息" :visible.sync="dialogVisible" width="50%" @closed="handleClose">
      <!-- 放表单信息 -->
      <el-form label-position="left" ref="form" :model="form" label-width="80px" :inline="true"
        :rules="rules">
        <el-row>
          <el-col :span="12">
            <el-form-item label="留言ID" prop="commentId">
              <el-input disabled v-model="form.commentId" maxlength="50"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="用户" prop="userName">
              <el-input disabled v-model="form.userId"></el-input>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="12">
            <el-form-item label="景点" prop="attractionName">
              <el-input disabled v-model="form.attractionName"></el-input>
            </el-form-item>
          </el-col>

          <el-col :span="12">
            <el-form-item label="评分" prop="rating">
              <el-rate v-model="+ form.rating" disabled style="margin-top: 5px;"></el-rate>
            </el-form-item>
          </el-col>
        </el-row>

        <el-row>
          <el-col :span="12">
            <el-form-item label="留言内容" prop="content">
              <el-input type="textarea" disabled v-model="form.content"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="状态" prop="status">
              <el-select v-model="form.status" placeholder="请选择状态">
                <el-option label="审核通过" value="1"></el-option>
                <el-option label="待审核" value="0"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>

      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="submit">确 定</el-button>
      </span>
    </el-dialog>

    <div class="manage-header">
      <!-- 搜索区域 -->
      <el-form :model="Commentform" :inline="true" size="small">
        <el-form-item>
          <el-input placeholder="请输入留言ID" v-model="Commentform.commentId"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button @click="onSubmit" type="primary" size="small">查询</el-button>
        </el-form-item>
      </el-form>
    </div>

    <div class="common-table">
      <el-table :data="tableData" height="90%">
        <!-- 留言ID -->
        <el-table-column prop="commentId" label="留言ID" width="100"></el-table-column>

        <!-- 用户ID -->
        <el-table-column prop="userName" label="用户" width="100"></el-table-column>

        <!-- 景点ID -->
        <el-table-column prop="attractionName" label="景点" width="100"></el-table-column>

        <!-- 评分 -->
        <el-table-column prop="rating" label="评分" width="100"></el-table-column>

        <!-- 留言内容 -->
        <el-table-column prop="content" label="留言内容" width="250">
          <template slot-scope="scope">
            <div class="ellipsis" :title="scope.row.content">{{ scope.row.content }}</div>
          </template>
        </el-table-column>

        <!-- 状态 -->
        <el-table-column prop="status" label="状态" width="100">
          <template slot-scope="scope">
            <span>{{ scope.row.status === 1 ? '审核通过' : '待审核' }}</span>
          </template>
        </el-table-column>

        <!-- 创建时间 -->
        <el-table-column prop="createTime" label="创建时间" width="150"></el-table-column>

        <!-- 操作列 -->
        <el-table-column label="操作" width="180">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.row)">编辑</el-button>
            <el-button type="danger" size="mini" @click="handleDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="pager">
        <el-pagination layout="prev, pager, next" :total="total"
          @current-change="handlePage"></el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import {
  getCommentList,
  addComment,
  deleteComment,
  updateComment,
} from "@/api"; // 导入API请求
export default {
  data() {
    return {
      dialogVisible: false,
      form: {
        commentId: "",
        userName: "",
        attractionId: "",
        content: "",
        rating: "",
        status: "",
        attractionName: "",
      },
      Commentform: {
        commentId: "",
      },
      rules: {
        commentId: [
          { required: true, message: "请输入留言ID", trigger: "blur" },
        ],
        userId: [{ required: true, message: "请输入用户ID", trigger: "blur" }],
        attractionId: [
          { required: true, message: "请输入景点ID", trigger: "blur" },
        ],
        content: [
          { required: true, message: "请输入留言内容", trigger: "blur" },
        ],
        status: [{ required: true, message: "请选择状态", trigger: "change" }],
      },
      tableData: [],
      modalType: 0, // 0表示新增，1表示编辑
      total: 0, // 当前tableData的总条数
      page: {
        pageNum: 1,
        pageSize: 10,
      },
    };
  },
  methods: {
    handleAdd() {
      this.modalType = 0;
      this.dialogVisible = true;
    },
    handleEdit(row) {
      this.modalType = 1;
      this.dialogVisible = true;
      this.form = { ...JSON.parse(JSON.stringify(row)) };
    },
    handleClose() {
      this.$refs.form.resetFields();
      this.dialogVisible = false;
    },
    submit() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.modalType === 0) {
            // 新增
            addComment(this.form).then(({ data }) => {
              if (data.code == 200) {
                this.$message.success("新增成功");
                this.handleClose();
                this.getList();
              }
            });
          } else {
            // 编辑
            updateComment(this.form).then(({ data }) => {
              if (data.code == 200) {
                this.$message.success(data.msg);
                this.handleClose();
                this.getList();
              } else {
                this.$message.error(data.msg);
              }
            });
          }
        }
      });
    },
    handleDelete(row) {
      this.$confirm("是否删除该留言", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          deleteComment({ commentId: row.commentId }).then(({ data }) => {
            if (data.code === 200) {
              this.$message.success("删除成功");
              this.getList();
            } else {
              this.$message.error(data.msg);
            }
          });
        })
        .catch(() => {
          this.$message.info("已取消删除");
        });
    },
    handlePage(val) {
      this.page.pageNum = val;
      this.getList();
    },
    onSubmit() {
      this.getList();
    },
    getList() {
      getCommentList({ ...this.page }).then(({ data }) => {
        console.log(data);
        if (data.code == 200) {
          this.tableData = data.data.records;
          this.total = data.data.total;
        } else {
          this.$message.error(data.msg);
        }
      });
    },
  },
  mounted() {
    this.getList();
  },
};
</script>

<style lang="less" scoped>
/* 设置文字省略 */
.ellipsis {
  white-space: nowrap; /* 禁止换行 */
  overflow: hidden; /* 超出部分隐藏 */
  text-overflow: ellipsis; /* 使用省略号代替超出部分 */
  width: 100%; /* 设置宽度 */
}

.manage {
  height: 90%;
  .manage-header {
    display: flex;
    justify-content: flex-end;
    align-items: center;
  }

  .common-table {
    position: relative;
    height: calc(100% - 62px);
    .pager {
      position: absolute;
      bottom: 0;
      right: 20px;
    }
  }
}
</style>
