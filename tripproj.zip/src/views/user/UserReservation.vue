<template>
  <div class="user-reservation">
    <div class="return">
      <router-link to="/userHome" class="backLink">返回</router-link>
    </div>
    <div class="title">
      我的预约
    </div>
    <span style="color: #a3a3a3;font-size: 12px;">预约时间过期后将无法操作</span>
    <el-divider></el-divider>
    <div class="common-table">
      <el-table :data="tableData" height="90%" style="width: 100%">
        <el-table-column prop="status" label="预约状态">
          <template slot-scope="scope">
            <el-tag :type="scope.row.status === '1' ? 'success' : 'danger'">
              {{ scope.row.status == '1' ? "已预约" : "已取消" }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="numPeople" label="预约人数"></el-table-column>
        <el-table-column prop="visitDate" label="预约时间"></el-table-column>
        <el-table-column prop="createTime" label="创建时间"></el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button :disabled="new Date(scope.row.visitDate) < new Date(currentTime)" size="mini"
              @click="editReservation(scope.row)">编辑</el-button>
            <el-button :disabled="new Date(scope.row.visitDate) < new Date(currentTime)"
              type="danger" size="mini" @click="cancel(scope.row)">取消预约</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="pager">
        <el-pagination :page-size="10" :pager-count="7" layout="prev, pager, next" :total="total"
          @current-change="handlePage">
        </el-pagination>
      </div>
    </div>
  </div>
</template>

<script>
import Cookies from "js-cookie";
import { deleteReservation } from "@/api"; // 导入API请求
import { getListByUserId } from "@/api";
export default {
  name: "UserReservation",
  data() {
    return {
      tableData: [],
      dialogVisible: false,
      currentTime: new Date().toISOString().split("T")[0],
      total: 0,
      userId: 0,
      page: {
        pageNum: 1,
        pageSize: 10,
      },
    };
  },
  methods: {
    //页面切换
    handlePage(val) {
      this.page.pageNum = val;
      this.getList();
    },
    // 编辑分类
    editReservation(data) {
      this.form = { ...data };
      this.dialogVisible = true;
    },
    cancel(row) {
      this.$confirm("是否取消该预定", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          deleteReservation({ reservationId: row.reservationId }).then(
            ({ data }) => {
              if (data.code == 200) {
                this.$message.success("取消成功");
                this.getList();
              } else {
                this.$message.error(data.msg);
              }
            }
          );
        })
        .catch(() => {
          this.$message.info("已取消删除");
        });
    },
    // 获取用户的预约列表
    getList() {
      getListByUserId({ userId: this.userId, ...this.page }).then(
        ({ data }) => {
          this.total = data.data.total;
          this.tableData = data.data.records;
          console.log(this.tableData);
        }
      );
    },
  },
  mounted() {
    this.userId = Cookies.get("userId");
    this.getList();
  },
};
</script>

<style scoped lang="less">
.user-reservation {
  padding: 20px;
  height: 100%;
  .return {
    .backLink {
      text-decoration: none;
      color: black;
    }
  }
  .title {
    font-size: 24px;
    color: rgb(37, 37, 37);
    width: 100px;
    font-weight: 500;
    margin: 0 auto;
  }
  .common-table {
    position: relative;
    padding-bottom: 30px;
    height: calc(100% - 62px);
    .pager {
      position: absolute;
      bottom: 0;
      right: 20px;
    }
  }
}
</style>