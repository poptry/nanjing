import http from "../utils/request";

// 请求数据;
export const login = (data) => {
  //返回一个promise对象
  return http.post("/user/login", data);
};
// 注册
export const register = (data) => {
  return http.post("/user/register", data);
};
// 图片上传oss
export const uploadImg = (data) => {
  return http.post("/oss/upload", data, {
    headers: { "Content-Type": "multipart/form-data" },
  });
};

//用户
// 获取用户列表
export const getUserList = (data) => {
  return http.post("/user/list", data);
};
// 查询用户
export const getUserById = (data) => http.post("/user/getById", data);
// 删除用户
export const deleteUser = (data) => {
  return http.post("/user/delete", data);
};
// 修改用户
export const updateUser = (data) => {
  return http.post("/user/update", data);
};

//获取分类 /category
export const getCategoryList = (data) => {
  return http.post("/category/list", data);
};
//添加分类
export const addCategory = (data) => {
  return http.post("/category/add", data);
};
//删除分类
export const deleteCategory = (data) => {
  return http.post("/category/delete", data);
};
//修改分类
export const updateCategory = (data) => {
  return http.post("/category/update", data);
};
//查询分类
export const getCategoryById = (data) => {
  return http.post("/category/getById", data);
};

//景区 /attraction
// 获取景区列表
export const getAttractionList = (data) => {
  return http.post("/attraction/list", data);
};
// 查询景区
export const getAttractionById = (data) => {
  return http.post("/attraction/getById", data);
};
// 添加景区
export const addAttraction = (data) => {
  return http.post("/attraction/add", data);
};
// 删除景区
export const deleteAttraction = (data) => {
  return http.post("/attraction/delete", data);
};
// 修改景区
export const updateAttraction = (data) => {
  return http.post("/attraction/update", data);
};

// 预定信息
// 获取预定列表
export const getReservationList = (data) => {
  return http.post("/reservation/list", data);
};
// 查询预定信息
export const getReservationById = (data) => {
  return http.post("/reservation/getById", data);
};
// 添加预定信息
export const addReservation = (data) => {
  return http.post("/reservation/add", data);
};
// 删除预定信息
export const deleteReservation = (data) => {
  return http.post("/reservation/delete", data);
};
// 修改预定信息
export const updateReservation = (data) => {
  return http.post("/reservation/update", data);
};
// 获取用户预定信息 listByUserId
export const getListByUserId = (data) => {
  return http.post("/reservation/listByUserId", data);
};

// 留言信息
// 获取留言列表
export const getCommentList = (data) => {
  return http.post("/comment/list", data);
};
// 查询留言信息
export const getCommentById = (data) => {
  return http.post("/comment/getById", data);
};
// 添加留言信息
export const addComment = (data) => {
  return http.post("/comment/add", data);
};
// 删除留言信息
export const deleteComment = (data) => {
  return http.post("/comment/delete", data);
};
// 修改留言信息
export const updateComment = (data) => {
  return http.post("/comment/update", data);
};
// listByAttractionId
export const getCommentsByAttraction = (data) => {
  return http.post("/comment/listByAttractionId", data);
};
