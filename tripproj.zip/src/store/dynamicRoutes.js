// import { adminRoutes } from "@/utils/routeData";
// export default {
//   state: {
//     dynamicRoute: adminRoutes,
//   },
//   mutations: {
//     // 设置动态路由
//     setDynamicRoute(state, routes) {
//       state.dynamicRoute = routes;
//     },
//     addMenu(state, router) {
//       if (state.dynamicRoute) {
//         // 添加根路由
//         router.addRoute(state.dynamicRoute);
//       }
//     },
//   },
// };
