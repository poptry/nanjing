// store/modules/category.js
export default {
  state: {
    scenicData: [],
  },
  mutations: {},
};
